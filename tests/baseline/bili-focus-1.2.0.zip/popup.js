import { STATE_KEY, emptyState, normalizeSettings, formatTime, isComplete, resumeTarget, cleanupCandidates, estimateBytes, validCover, coverThumbnail } from './shared/model.js';
import { DEFAULT_ACCENT, normalizeAccentColor, appearancePalette } from './shared/appearance.js';
import { needsCleanupWarning } from './shared/limits.js';

const $ = selector => document.querySelector(selector);
const systemTheme = matchMedia('(prefers-color-scheme: dark)');
const PAGE_SIZE = 10;
const placeholder = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m10 9 5 3-5 3z"/></svg>';
let state = emptyState(), selectedKey, filter = 'all', pageNumber = 1, loadError = false;
let toastTimer, undoId, dialogAction, disposed = false, listSignature = '', bookmarkSignature = '', coverSignature;
let rarePromise, rareController, lastToggle;
let actualStorageBytes, usageTimer;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function actionButton(text, label, action, className = 'icon-button') {
  const b = el('button', className, text);
  b.type = 'button'; b.title = label; b.setAttribute('aria-label', label);
  b.addEventListener('click', async () => {
    b.disabled = true;
    try { await action(); } catch (error) { toast(error.message); } finally { b.disabled = false; }
  });
  return b;
}
async function send(type, payload = {}) {
  const response = await chrome.runtime.sendMessage({ type, ...payload });
  if (!response?.ok) throw new Error(response?.error || '操作失败，请重试');
  return response.result;
}
function toast(text, id, duration = 4200) {
  clearTimeout(toastTimer); undoId = id;
  $('#toast span').textContent = text; $('#toast').hidden = false; $('#undo').hidden = !id;
  toastTimer = setTimeout(() => { $('#toast').hidden = true; undoId = undefined; }, duration);
}
function relative(at) {
  if (!at) return '尚未观看';
  const d = Math.max(0, Date.now() - at);
  return d < 60000 ? '刚刚' : d < 3600000 ? `${Math.floor(d / 60000)} 分钟前` : d < 86400000 ? `${Math.floor(d / 3600000)} 小时前` : `${Math.floor(d / 86400000)} 天前`;
}
function applyPalette(color, dark = document.documentElement.dataset.theme === 'dark') {
  for (const [key, value] of Object.entries(appearancePalette(color, dark))) document.documentElement.style.setProperty(key, value);
}
function applyTheme() {
  const dark = state.settings.theme === 'dark' || (state.settings.theme === 'system' && systemTheme.matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  applyPalette(state.settings.accentColor, dark);
  const label = dark ? '切换到浅色' : '切换到深色';
  $('#theme-toggle').textContent = dark ? '☀' : '☾';
  $('#theme-toggle').title = label; $('#theme-toggle').setAttribute('aria-label', label);
  rareController?.update(state.settings.theme, systemTheme.matches, state.settings.accentColor);
}
function currentVideo() { return state.videos[selectedKey]; }
function sortedVideos() {
  return Object.entries(state.videos).sort(([, a], [, b]) => Number(b.pinned) - Number(a.pinned) || b.lastWatchedAt - a.lastWatchedAt || b.addedAt - a.addedAt);
}
function filteredVideos(videos) {
  return videos.filter(([, v]) => filter === 'all' || (filter === 'completed' ? isComplete(v, state.settings) : !isComplete(v, state.settings)));
}
function renderFocus() {
  const v = currentVideo();
  const target = v ? resumeTarget(v, state.settings) : null;
  $('#focus').setAttribute('aria-busy', 'false');
  $('#resume-button').disabled = false;
  $('#focus-title').textContent = v ? v.title : '还没有视频';
  $('#focus-title').title = v?.title || '';
  $('#focus-meta').textContent = v ? `${v.totalPages > 1 ? `P${v.page} · ${v.partTitle} · ` : ''}${v.ownerName || ''}` : '';
  $('#focus-status').textContent = v ? isComplete(v, state.settings) ? '已看完' : v.lastWatchedAt ? '上次观看' : '未开始' : '';
  $('#focus-time').textContent = v ? `${formatTime(v.positionSec)} / ${formatTime(v.duration)}` : '';
  $('#focus-progress').style.width = v?.duration ? `${Math.min(100, v.positionSec / v.duration * 100)}%` : '0%';
  $('#resume-label').textContent = target?.label || '添加视频';
  $('#resume-button').setAttribute('aria-label', target?.label || '添加第一个视频');
  $('#focus-last').textContent = target?.lastPage ? '已是最后一P' : v ? relative(v.lastWatchedAt) : '';
  $('#replay').hidden = !v || !isComplete(v, state.settings);
  $('#focus-warning').hidden = !v?.invalid && !v?.refreshError;
  $('#focus-warning').textContent = v?.refreshError || '稿件暂时失效，已保留记录与书签';
  $('#bookmarks-toggle').disabled = !v;
  $('#bookmark-badge').textContent = v?.bookmarks.length || 0;
  const nextCover = v?.cover || '';
  if (coverSignature !== nextCover) {
    coverSignature = nextCover;
    $('#focus-cover').replaceChildren(createCover(nextCover, 'focus-thumbnail', 80, 48));
  }
}
function createCover(url, className, width, height) {
  const cover = el('span', `thumbnail ${className}`); cover.innerHTML = placeholder;
  cover.setAttribute('aria-hidden', 'true');
  const original = validCover(url), thumbnail = coverThumbnail(url);
  if (!thumbnail) { cover.title = '暂无封面'; return cover; }
  const img = el('img'); img.referrerPolicy = 'no-referrer'; img.loading = 'lazy'; img.decoding = 'async'; img.alt = ''; img.width = width; img.height = height;
  let retried = false;
  img.addEventListener('error', () => {
    if (!retried && thumbnail !== original) { retried = true; img.src = original; return; }
    img.remove(); cover.title = '封面暂不可用，可在书签面板刷新信息'; cover.dataset.coverState = 'error';
  });
  img.addEventListener('load', () => { cover.dataset.coverState = 'loaded'; }, { once: true });
  img.src = thumbnail; cover.append(img); return cover;
}
function pendingRow(key, p) {
  const row = el('article', 'pending-row');
  const body = el('div', 'row-body');
  body.append(el('span', 'row-title', '等待补全视频信息'), el('span', 'row-meta', p.error || p.url)); body.title = `${p.url}\n${p.error || ''}`;
  row.append(body,
    actionButton('↻', '重试获取视频信息', async () => { const r = await send('RETRY', { url: p.url, entire: p.entire }); toast(r.message); }),
    actionButton('×', '移除待补全链接', async () => { const r = await send('DELETE_PENDING', { key }); toast('已移除待补全链接', r.undoId, 8000); }));
  return row;
}
function videoRow(key, v) {
  const row = el('button', 'list-row'); row.type = 'button'; row.dataset.key = key;
  row.setAttribute('aria-label', `选择 ${v.title} P${v.page}`);
  const body = el('span', 'row-body'); body.append(el('span', 'row-title', v.title), el('span', 'row-meta', `${v.totalPages > 1 ? `P${v.page} · ${v.partTitle}` : v.ownerName || '单P视频'}`));
  row.append(createCover(v.cover, 'row-cover', 64, 40), body, el('span', 'row-position'));
  row.addEventListener('click', () => { selectedKey = key; renderFocus(); updateRowStates(); bookmarkSignature = ''; renderBookmarks(); });
  return row;
}
function updateRowStates() {
  for (const row of $('#list').querySelectorAll('.list-row')) {
    const v = state.videos[row.dataset.key]; if (!v) continue;
    row.setAttribute('aria-pressed', String(row.dataset.key === selectedKey));
    row.querySelector('.row-position').textContent = isComplete(v, state.settings) ? '已看完' : formatTime(v.positionSec);
  }
}
function renderList(videos) {
  const pending = filter === 'all' ? Object.entries(state.pending || {}) : [];
  const entries = [...pending.map(([key, value]) => ({ key, value, pending: true })), ...filteredVideos(videos).map(([key, value]) => ({ key, value }))];
  const pages = Math.max(1, Math.ceil(entries.length / PAGE_SIZE)); pageNumber = Math.min(pageNumber, pages);
  const visible = entries.slice((pageNumber - 1) * PAGE_SIZE, pageNumber * PAGE_SIZE);
  const signature = JSON.stringify([filter, pageNumber, visible.map(e => [e.key, e.pending, e.value.title, e.value.partTitle, e.value.ownerName, e.value.error, e.value.cover])]);
  if (listSignature !== signature) {
    listSignature = signature;
    const scroll = $('#list').scrollTop;
    const activeKey = $('#list').contains(document.activeElement) ? document.activeElement.dataset.key : undefined;
    const fragment = document.createDocumentFragment();
    for (const e of visible) fragment.append(e.pending ? pendingRow(e.key, e.value) : videoRow(e.key, e.value));
    if (!entries.length) fragment.append(el('p', 'empty-list', '暂无视频'));
    $('#list').replaceChildren(fragment); $('#list').scrollTop = scroll;
    if (activeKey) [...$('#list').querySelectorAll('.list-row')].find(row => row.dataset.key === activeKey)?.focus({ preventScroll: true });
  }
  updateRowStates(); $('#list').setAttribute('aria-busy', 'false');
  $('#count').textContent = videos.length + Object.keys(state.pending || {}).length;
  $('#pagination').hidden = pages <= 1; $('#page-number').textContent = `${pageNumber} / ${pages}`;
  $('#prev').disabled = pageNumber <= 1; $('#next').disabled = pageNumber >= pages;
}
function renderBookmarks() {
  if ($('#bookmarks-panel').hidden) return;
  const v = currentVideo();
  if (!v) { closePanels(); return; }
  const signature = JSON.stringify([selectedKey, v.bookmarks, v.title, v.partTitle]);
  if (bookmarkSignature === signature) return;
  bookmarkSignature = signature;
  $('#bookmark-count').textContent = v.bookmarks.length;
  $('#bookmark-video').textContent = `${v.title}${v.totalPages > 1 ? ` · P${v.page}` : ''}`;
  const fragment = document.createDocumentFragment();
  for (const b of [...v.bookmarks].sort((a, b) => a.sec - b.sec)) {
    const key = selectedKey, row = el('li', 'bookmark-row');
    const jump = actionButton('', `跳转 ${formatTime(b.sec)} ${b.note}`, () => send('OPEN', { key, mode: 'bookmark', id: b.id }), 'bookmark-jump');
    jump.append(el('time', '', formatTime(b.sec)), el('span', '', b.note || '未填写备注'));
    jump.title = `${b.note || '时间书签'} · ${new Date(b.createdAt).toLocaleString('zh-CN')}`;
    row.append(jump, actionButton('✎', '修改书签备注', () => noteDialog({ type: 'BOOKMARK_EDIT', key, id: b.id, sec: b.sec, note: b.note })), actionButton('×', '删除书签', () => send('BOOKMARK_DELETE', { key, id: b.id })));
    fragment.append(row);
  }
  if (!v.bookmarks.length) fragment.append(el('li', 'help', '暂无书签'));
  $('#bookmark-list').replaceChildren(fragment);
}
function render() {
  const videos = sortedVideos();
  if (!state.videos[selectedKey]) selectedKey = videos[0]?.[0];
  renderFocus(); renderList(videos); renderBookmarks();
  if (!$('#settings').hidden) settingsUI();
}
function formatBytes(bytes) { return bytes < 1024 ? `${bytes} B` : bytes < 1048576 ? `${(bytes / 1024).toFixed(1)} KB` : bytes < 1073741824 ? `${(bytes / 1048576).toFixed(2)} MB` : `${(bytes / 1073741824).toFixed(2)} GB`; }
async function refreshUsage() {
  try {
    if (!chrome.storage.local.getBytesInUse) return;
    const bytes = await chrome.storage.local.getBytesInUse(null);
    if (disposed) return;
    actualStorageBytes = bytes;
    $('#storage-warning').hidden = !needsCleanupWarning(bytes);
    if (!$('#settings').hidden) cleanupUI();
  } catch { /* Missing usage information must not block the list. */ }
}
function cleanupUI() {
  const quota = chrome.storage.local.QUOTA_BYTES || 10485760, used = actualStorageBytes ?? estimateBytes(state);
  $('#storage-usage').textContent = `约 ${formatBytes(used)}`;
  $('#storage-bar').style.width = `${Math.min(100, used / quota * 100)}%`;
  const marks = Object.values(state.videos).reduce((n, v) => n + v.bookmarks.length, 0);
  $('#storage-detail').textContent = `${Object.keys(state.videos).length} 个分P · ${marks} 个书签 · 上限约 ${formatBytes(quota)}${used / quota > .85 ? ' · 空间将满，建议先备份再清理' : ''}`;
  const days = $('#cleanup-days');
  if (![...days.options].some(o => o.value === String(state.settings.cleanupAfterDays))) days.add(new Option(`${state.settings.cleanupAfterDays} 天`, String(state.settings.cleanupAfterDays)));
  days.value = String(state.settings.cleanupAfterDays);
  $('#cleanup-keep').checked = state.settings.cleanupKeepBookmarked;
  const preview = cleanupCandidates(state);
  $('#cleanup-preview').textContent = preview.count ? `可清理 ${preview.count} 条，预计释放 ${formatBytes(preview.bytes)}` : '没有符合条件的旧记录';
  $('#cleanup-run').disabled = !preview.count;
  const recent = Object.entries(state.trash).filter(([, t]) => t.kind === 'batch' && t.expiresAt > Date.now()).sort(([, a], [, b]) => b.expiresAt - a.expiresAt)[0];
  $('#cleanup-undo').hidden = !recent; $('#cleanup-undo').dataset.id = recent?.[0] || '';
}
function settingsUI() {
  $('#accent-picker').value = state.settings.accentColor;
  if (document.activeElement !== $('#accent-hex')) $('#accent-hex').value = state.settings.accentColor.toUpperCase();
  for (const b of document.querySelectorAll('[data-accent-color]')) b.setAttribute('aria-pressed', String(b.dataset.accentColor === state.settings.accentColor));
  $('#new-tab').checked = state.settings.openInNewTab; $('#default-entire').checked = state.settings.addEntireCollectionDefault;
  for (const [selector, value, suffix] of [['#interval', state.settings.sampleIntervalSec, ' 秒'], ['#completion', state.settings.completionPercent, '%'], ['#remaining', state.settings.completionRemainingSec, ' 秒']]) {
    const s = $(selector); if (![...s.options].some(o => o.value === String(value))) s.add(new Option(`${value}${suffix}`, String(value)));
    s.value = String(value);
  }
  cleanupUI();
}
function syncPanelButtons(id) {
  for (const [button, panel] of [['settings-toggle', 'settings'], ['more-toggle', 'settings'], ['add-toggle', 'add-panel'], ['bookmarks-toggle', 'bookmarks-panel']]) $(`#${button}`).setAttribute('aria-expanded', String(panel === id));
}
function closePanels() { for (const panel of document.querySelectorAll('.drawer')) panel.hidden = true; $('main').inert = false; syncPanelButtons(); }
async function loadRareTheme() {
  if (rareController || rarePromise) return rarePromise;
  const host = $('#rare-theme-host'); host.dataset.rareState = 'loading'; $('#theme-error').hidden = true;
  performance.mark('rare-theme:request');
  rarePromise = (async () => {
    const css = document.createElement('link'); css.rel = 'stylesheet'; css.href = 'assets/rare-theme.css';
    const styles = new Promise((resolve, reject) => { css.onload = resolve; css.onerror = () => reject(new Error('主题样式未载入')); });
    document.head.append(css);
    const [module] = await Promise.all([import('./assets/rare-theme.js'), styles]);
    if (disposed) return;
    rareController = await module.mountThemeSelector(host, state.settings.theme, systemTheme.matches, chooseTheme, state.settings.accentColor);
    if (disposed) { rareController.destroy(); return; }
    rareController.update(state.settings.theme, systemTheme.matches, state.settings.accentColor);
    host.dataset.rareState = 'ready';
    performance.mark('rare-theme:ready'); performance.measure('rare-theme:first-mount', 'rare-theme:request', 'rare-theme:ready');
  })().catch(() => {
    if (disposed) return;
    host.dataset.rareState = 'error'; $('#theme-error').hidden = false;
    rarePromise = undefined;
  });
  return rarePromise;
}
function openPanel(id, toggle) {
  const opening = $(`#${id}`).hidden;
  closePanels();
  if (!opening) return;
  lastToggle = toggle || document.activeElement;
  $(`#${id}`).hidden = false; $('main').inert = true; syncPanelButtons(id);
  if (id === 'settings') { settingsUI(); void loadRareTheme(); }
  if (id === 'bookmarks-panel') { bookmarkSignature = ''; renderBookmarks(); }
  if (id === 'add-panel') $('#video-link').focus();
}
async function chooseTheme(theme) { try { await send('SETTINGS', { settings: { theme } }); } catch (error) { toast(error.message); } }
async function chooseAccent(value) {
  if (!/^#[\da-f]{6}$/i.test(value)) { $('#accent-hex').setCustomValidity('请输入 #RRGGBB 格式的颜色'); $('#accent-hex').reportValidity(); return; }
  $('#accent-hex').setCustomValidity('');
  const accentColor = normalizeAccentColor(value);
  try { await send('SETTINGS', { settings: { accentColor } }); }
  catch (error) { applyTheme(); settingsUI(); toast(error.message); }
}
function noteDialog(action) {
  dialogAction = action; $('#note-title').textContent = action.type === 'BOOKMARK_EDIT' ? '修改书签备注' : '记录时间点';
  $('#note-time').textContent = formatTime(action.sec); $('#note-input').value = action.note; $('#note-error').hidden = true;
  $('#note-dialog').showModal(); $('#note-input').focus();
}
async function addLink(url) {
  const r = await send('ADD', { url, entire: $('#entire').checked });
  $('#video-link').value = ''; pageNumber = 1; filter = 'all'; setFilter(); render();
  closePanels(); toast(r.message, undefined, r.pending ? 6500 : 4200);
}
function setFilter() { for (const b of document.querySelectorAll('[data-filter]')) b.setAttribute('aria-pressed', String(b.dataset.filter === filter)); }

$('#resume-button').addEventListener('click', async event => {
  if (loadError) { location.reload(); return; }
  if (!currentVideo()) { event.stopPropagation(); openPanel('add-panel', $('#resume-button')); return; }
  const key = selectedKey, b = $('#resume-button'); b.disabled = true;
  try { await send('OPEN', { key, mode: 'resume' }); } catch (error) { toast(error.message); } finally { b.disabled = false; }
});
$('#replay').addEventListener('click', async () => { try { await send('OPEN', { key: selectedKey, mode: 'last' }); } catch (error) { toast(error.message); } });
$('#theme-toggle').addEventListener('click', () => chooseTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
for (const b of document.querySelectorAll('[data-accent-color]')) b.addEventListener('click', () => { void chooseAccent(b.dataset.accentColor); });
$('#accent-picker').addEventListener('change', event => { void chooseAccent(event.target.value); });
$('#accent-hex').addEventListener('input', () => $('#accent-hex').setCustomValidity(''));
$('#accent-hex').addEventListener('change', event => { void chooseAccent(event.target.value.trim()); });
$('#accent-hex').addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); void chooseAccent(event.target.value.trim()); } });
$('#accent-reset').addEventListener('click', () => { void chooseAccent(DEFAULT_ACCENT); });
$('#theme-retry').addEventListener('click', () => { void loadRareTheme(); });
for (const [button, panel] of [['settings-toggle', 'settings'], ['more-toggle', 'settings'], ['add-toggle', 'add-panel'], ['bookmarks-toggle', 'bookmarks-panel']]) $(`#${button}`).addEventListener('click', () => openPanel(panel, $(`#${button}`)));
for (const b of document.querySelectorAll('[data-close-panel]')) b.addEventListener('click', () => { closePanels(); lastToggle?.focus(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('#note-dialog').open) { closePanels(); lastToggle?.focus(); } });
document.addEventListener('click', event => { if (!event.target.closest('.drawer,.utility-bar,.header,dialog,#toast,#storage-warning')) closePanels(); });
for (const b of document.querySelectorAll('[data-filter]')) b.addEventListener('click', () => {
  filter = b.dataset.filter; pageNumber = 1;
  const first = filteredVideos(sortedVideos())[0]; if (first && !filteredVideos(sortedVideos()).some(([key]) => key === selectedKey)) selectedKey = first[0];
  setFilter(); render();
});
$('#prev').addEventListener('click', () => { pageNumber--; render(); }); $('#next').addEventListener('click', () => { pageNumber++; render(); });
$('#add-form').addEventListener('submit', async event => {
  event.preventDefault(); const b = $('#add-form button'); b.disabled = true; $('#add-error').hidden = true;
  try { await addLink($('#video-link').value); } catch (error) { $('#add-error').textContent = error.message; $('#add-error').hidden = false; } finally { b.disabled = false; }
});
$('#add-current').addEventListener('click', async () => {
  const b = $('#add-current'); b.disabled = true; $('#add-error').hidden = true;
  try { const [tab] = await chrome.tabs.query({ active: true, currentWindow: true }); await addLink(tab?.url || ''); }
  catch (error) { $('#add-error').textContent = error.message; $('#add-error').hidden = false; } finally { b.disabled = false; }
});
$('#add-bookmark').addEventListener('click', async () => {
  const key = selectedKey; $('#add-bookmark').disabled = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url?.startsWith('https://www.bilibili.com/video/')) throw new Error('请先打开对应分P的视频页，再记录当前播放时间');
    let response;
    try { response = await chrome.tabs.sendMessage(tab.id, { type: 'CURRENT_BOOKMARK', key }); } catch { throw new Error('请刷新视频页后再记录书签'); }
    if (!response?.ok) throw new Error(response?.error || '当前播放页尚未就绪');
    noteDialog({ type: 'BOOKMARK_ADD', key, sec: response.sec, note: '' });
  } catch (error) { toast(error.message); } finally { $('#add-bookmark').disabled = false; }
});
$('#refresh-record').addEventListener('click', async () => { const v = currentVideo(); if (!v) return; try { await send('REFRESH', { bvid: v.bvid }); toast('视频信息已更新'); } catch (error) { toast(error.message); } });
$('#delete-record').addEventListener('click', async () => { if (!currentVideo()) return; try { const r = await send('DELETE', { key: selectedKey }); closePanels(); toast('已移出重点关注', r.undoId, 8000); } catch (error) { toast(error.message); } });
for (const id of ['note-close', 'note-cancel']) $(`#${id}`).addEventListener('click', () => $('#note-dialog').close());
$('#note-form').addEventListener('submit', async event => {
  event.preventDefault(); const b = $('#note-form button[type=submit]'); b.disabled = true;
  try { const { type, ...payload } = dialogAction; await send(type, { ...payload, note: $('#note-input').value }); $('#note-dialog').close(); toast(type === 'BOOKMARK_ADD' ? '已保存书签' : '备注已更新'); }
  catch (error) { $('#note-error').textContent = error.message; $('#note-error').hidden = false; } finally { b.disabled = false; }
});
for (const [id, key, boolean] of [['new-tab', 'openInNewTab', true], ['default-entire', 'addEntireCollectionDefault', true], ['interval', 'sampleIntervalSec'], ['completion', 'completionPercent'], ['remaining', 'completionRemainingSec'], ['cleanup-days', 'cleanupAfterDays'], ['cleanup-keep', 'cleanupKeepBookmarked', true]]) $(`#${id}`).addEventListener('change', async event => {
  const b = event.target; b.disabled = true;
  try { await send('SETTINGS', { settings: { [key]: boolean ? b.checked : Number(b.value) } }); }
  catch (error) { toast(error.message); settingsUI(); } finally { b.disabled = false; }
});
$('#cleanup-run').addEventListener('click', async () => { $('#cleanup-run').disabled = true; try { const r = await send('CLEANUP'); toast(r.message, r.undoId, 8000); } catch (error) { toast(error.message); } finally { cleanupUI(); } });
$('#cleanup-undo').addEventListener('click', async () => { try { await send('UNDO', { id: $('#cleanup-undo').dataset.id }); toast('已恢复清理的记录'); } catch (error) { toast(error.message); } });
$('#storage-cleanup').addEventListener('click', () => {
  if ($('#settings').hidden) openPanel('settings', $('#storage-cleanup'));
  $('#cleanup-panel').open = true;
  requestAnimationFrame(() => { $('#settings').scrollTop = $('#cleanup-panel').offsetTop - 16; });
});
$('#export').addEventListener('click', () => {
  const backup = { schemaVersion: 1, exportedAt: Date.now(), videos: state.videos, pending: state.pending, settings: state.settings };
  const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }));
  const a = el('a'); a.href = url; a.download = `重点关注-备份-${new Date().toLocaleDateString('sv-SE')}.json`; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000); toast('已导出本机 JSON 备份');
});
$('#import').addEventListener('click', () => $('#import-file').click());
$('#import-file').addEventListener('change', async event => {
  const file = event.target.files[0]; if (!file) return; $('#import').disabled = true;
  try { if (file.size > 8 * 1024 * 1024) throw new Error('备份超过 8MB，请检查文件'); const r = await send('IMPORT', { data: JSON.parse(await file.text()) }); toast(r.message); }
  catch (error) { toast(error instanceof SyntaxError ? '这不是有效的 JSON 备份文件' : error.message, undefined, 6500); }
  finally { event.target.value = ''; $('#import').disabled = false; }
});
$('#toast-close').addEventListener('click', () => { clearTimeout(toastTimer); $('#toast').hidden = true; });
$('#undo').addEventListener('click', async () => { const id = undoId; $('#undo').disabled = true; try { await send('UNDO', { id }); toast('已恢复到清单'); } catch (error) { toast(error.message); } finally { $('#undo').disabled = false; } });
function onStorage(changes, area) {
  const next = changes[STATE_KEY]?.newValue;
  if (area !== 'local' || !next || next.schemaVersion !== 1) return;
  state = { ...emptyState(), ...next, settings: normalizeSettings(next.settings) };
  applyTheme(); render();
  clearTimeout(usageTimer); usageTimer = setTimeout(() => { void refreshUsage(); }, 150);
}
chrome.storage.onChanged.addListener(onStorage); systemTheme.addEventListener('change', applyTheme);
window.addEventListener('pagehide', () => {
  disposed = true; clearTimeout(toastTimer); clearTimeout(usageTimer);
  chrome.storage.onChanged.removeListener(onStorage); systemTheme.removeEventListener('change', applyTheme); rareController?.destroy();
}, { once: true });
try {
  // Exactly one initial local state read. Rare UI, React and its stylesheet are
  // not requested until the user opens settings; no network gates the first view.
  const result = await chrome.storage.local.get(STATE_KEY);
  if (result[STATE_KEY]?.schemaVersion && result[STATE_KEY].schemaVersion !== 1) throw new Error('本机数据版本暂不支持');
  state = { ...emptyState(), ...result[STATE_KEY], settings: normalizeSettings(result[STATE_KEY]?.settings) };
  applyTheme(); $('#entire').checked = state.settings.addEntireCollectionDefault; render();
  const recent = Object.entries(state.trash).filter(([, t]) => t.expiresAt > Date.now()).sort(([, a], [, b]) => b.expiresAt - a.expiresAt)[0];
  if (recent) toast(recent[1].kind === 'batch' ? `已清理 ${recent[1].count} 条旧记录` : '刚刚移除了一个条目', recent[0], Math.min(8000, recent[1].expiresAt - Date.now()));
} catch (error) {
  loadError = true; $('#focus').setAttribute('aria-busy', 'false'); $('#list').setAttribute('aria-busy', 'false');
  $('#focus-title').textContent = '暂时无法读取本机清单'; $('#focus-meta').textContent = error.message;
  $('#resume-label').textContent = '重新读取'; $('#resume-button').setAttribute('aria-label', '重新读取'); $('#resume-button').disabled = false;
  $('#list').replaceChildren(el('p', 'empty-list', '重新读取不会清空已保存的数据。'));
}
document.body.dataset.ready = 'true'; performance.mark('focus:ready');
requestAnimationFrame(() => { void refreshUsage(); });
