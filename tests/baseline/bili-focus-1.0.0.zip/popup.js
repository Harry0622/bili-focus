import { STATE_KEY, emptyState, normalizeSettings, formatTime, isComplete, resumeTarget, cleanupCandidates, estimateBytes } from './shared/model.js';
const $ = selector => document.querySelector(selector);
const svg = path => `<svg viewBox="0 0 24 24" aria-hidden="true">${path}</svg>`;
const icons = { play: svg('<path d="m8 5 11 7-11 7z"/>'), arrow: svg('<path d="M5 12h14m-5-5 5 5-5 5"/>'), bookmark: svg('<path d="M6 4h12v17l-6-4-6 4z"/>'), chevron: svg('<path d="m9 6 6 6-6 6"/>'), delete: svg('<path d="M4 6h16M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7m4-7v7"/>'), refresh: svg('<path d="M20 10a8 8 0 1 0-2 8M20 4v6h-6"/>'), user: svg('<circle cx="12" cy="8" r="3"/><path d="M5 21v-3a7 7 0 0 1 14 0v3"/>'), screen: svg('<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m10 9 5 3-5 3z"/>') };
let state = emptyState(), filter = 'all', page = 1, dialogAction, toastTimer, undoId;
const openDetails = new Set(), PAGE_SIZE = 10;
const systemTheme = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  const theme = state.settings.theme;
  const dark = theme === 'dark' || (theme === 'system' && systemTheme.matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  const label = dark ? '切换到浅色' : '切换到深色';
  $('#theme-toggle').textContent = dark ? '☀' : '☾'; $('#theme-toggle').title = label; $('#theme-toggle').setAttribute('aria-label', label);
  for (const b of document.querySelectorAll('[data-theme-choice]')) b.setAttribute('aria-pressed', String(b.dataset.themeChoice === theme));
}
systemTheme.addEventListener('change', applyTheme);
function formatBytes(bytes) { return bytes < 1024 ? `${bytes} B` : bytes < 1048576 ? `${(bytes / 1024).toFixed(1)} KB` : `${(bytes / 1048576).toFixed(2)} MB`; }
function cleanupUI() {
  const quota = chrome.storage.local.QUOTA_BYTES || 10485760, used = estimateBytes(state);
  $('#storage-usage').textContent = `约 ${formatBytes(used)} / ${formatBytes(quota)}`;
  $('#storage-bar').style.width = `${Math.min(100, used / quota * 100)}%`;
  const marks = Object.values(state.videos).reduce((n, v) => n + v.bookmarks.length, 0);
  $('#storage-detail').textContent = `${Object.keys(state.videos).length} 个分P · ${marks} 个书签 · ${Object.keys(state.pending).length} 个待补全链接${used / quota > .85 ? ' · 空间将满，建议先导出备份再清理' : ''}`;
  $('#cleanup-days').value = String(state.settings.cleanupAfterDays); $('#cleanup-keep').checked = state.settings.cleanupKeepBookmarked; $('#auto-cleanup').checked = state.settings.autoCleanup;
  if (!$('#cleanup-days').value) $('#cleanup-days').add(new Option(`${state.settings.cleanupAfterDays} 天`, String(state.settings.cleanupAfterDays), true, true));
  const preview = cleanupCandidates(state);
  $('#cleanup-preview').textContent = preview.count ? `可清理 ${preview.count} 条，预计释放 ${formatBytes(preview.bytes)}` : '没有符合条件的旧记录';
  $('#cleanup-run').disabled = !preview.count;
  const recent = Object.entries(state.trash).filter(([, t]) => t.kind === 'batch' && t.automatic && t.expiresAt > Date.now()).sort(([, a], [, b]) => b.expiresAt - a.expiresAt)[0];
  $('#cleanup-undo').hidden = !recent; $('#cleanup-undo').dataset.id = recent?.[0] || '';
}
function el(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; }
function button(text, title, action, className = 'icon-button') {
  const b = el('button', className); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title);
  if (text.startsWith('<svg')) b.innerHTML = text; else b.textContent = text;
  b.addEventListener('click', async () => { b.disabled = true; try { await action(); } catch (e) { toast(e.message); } finally { b.disabled = false; } }); return b;
}
async function send(type, payload = {}) { const response = await chrome.runtime.sendMessage({ type, ...payload }); if (!response?.ok) throw new Error(response?.error || '操作失败，请重试'); return response.result; }
function toast(text, id, duration = 4200) {
  clearTimeout(toastTimer); undoId = id; $('#toast span').textContent = text; $('#toast').hidden = false; $('#undo').hidden = !id;
  toastTimer = setTimeout(() => { $('#toast').hidden = true; undoId = undefined; }, duration);
}
$('#toast-close').addEventListener('click', () => { clearTimeout(toastTimer); $('#toast').hidden = true; });
$('#undo').addEventListener('click', async () => { const id = undoId; $('#undo').disabled = true; try { await send('UNDO', { id }); toast('已恢复到清单'); } catch (e) { toast(e.message); } finally { $('#undo').disabled = false; } });
function relative(at) { if (!at) return '尚未观看'; const d = Math.max(0, Date.now() - at); return d < 60000 ? '刚刚采集' : d < 3600000 ? `${Math.floor(d / 60000)} 分钟前` : d < 86400000 ? `${Math.floor(d / 3600000)} 小时前` : `${Math.floor(d / 86400000)} 天前`; }
function settingsUI() {
  applyTheme();
  $('#new-tab').checked = state.settings.openInNewTab; $('#default-entire').checked = state.settings.addEntireCollectionDefault;
  for (const [selector, value, suffix] of [['#interval', state.settings.sampleIntervalSec, ' 秒'], ['#completion', state.settings.completionPercent, '%'], ['#remaining', state.settings.completionRemainingSec, ' 秒']]) {
    const s = $(selector); if (![...s.options].some(o => o.value === String(value))) s.add(new Option(`${value}${suffix}`, String(value)));
    s.value = String(value);
  }
  if (!$('#settings').hidden) cleanupUI();
}
function card(key, v, index) {
  const complete = isComplete(v, state.settings), target = resumeTarget(v, state.settings);
  const node = el('article', 'card'); node.dataset.key = key;
  const top = el('div', 'card-top'), cover = el('div', 'cover'); cover.innerHTML = icons.screen;
  if (v.cover) { const img = el('img'); img.src = v.cover; img.loading = 'lazy'; img.decoding = 'async'; img.referrerPolicy = 'no-referrer'; img.alt = ''; img.width = 76; img.height = 53; img.addEventListener('error', () => { img.remove(); cover.title = '封面暂不可用'; }, { once: true }); cover.append(img); }
  const part = el('span', 'part-badge', (v.totalPages || 1) > 1 ? `P${v.page} / ${v.totalPages}` : '单P视频'); cover.append(part); top.append(cover);
  const info = el('div', 'card-text'); const title = el('h3', '', v.title); title.title = v.title; info.append(title);
  const owner = el('div', 'owner'); owner.innerHTML = icons.user; owner.append(document.createTextNode(v.ownerName || 'UP主信息待补全')); info.append(owner); top.append(info); node.append(top);
  const tools = el('div', 'card-tools'); tools.append(button(icons.refresh, '刷新视频信息', () => send('REFRESH', { bvid: v.bvid }).then(() => toast('视频信息已更新'))), button(icons.delete, '删除此分P', async () => { const r = await send('DELETE', { key }); toast('已移出重点关注', r.undoId, 8000); }, 'icon-button delete')); node.append(tools);
  if ((v.totalPages || 1) > 1) node.append(el('p', 'part-title', `P${v.page} · ${v.partTitle}`));
  const progress = el('div', 'progress-info'); progress.append(el('strong', '', complete ? '已看完' : v.lastWatchedAt ? '上次看到' : '等待开始')); progress.append(el('span', '', `${formatTime(v.positionSec)} / ${formatTime(v.duration)}`)); node.append(progress);
  const track = el('div', 'progress-track'), bar = el('div', 'progress-bar'); bar.style.setProperty('--progress', v.duration ? Math.min(1, v.positionSec / v.duration) : 0); track.append(bar); node.append(track);
  const resume = button('', target.label, () => send('OPEN', { key, mode: 'resume' }), 'primary'); const left = el('span', 'play-symbol'); left.innerHTML = icons.play; left.append(document.createTextNode(target.label)); resume.append(left); const arrow = el('span'); arrow.innerHTML = icons.arrow; resume.append(arrow); node.append(resume);
  const last = el('div', 'last-watch'); last.append(el('span', '', target.lastPage ? '已是最后一P' : relative(v.lastWatchedAt))); if (complete) last.append(button('重看上次位置', '重看上次位置', () => send('OPEN', { key, mode: 'last' }), 'text-button')); node.append(last);
  if (v.invalid || v.refreshError) node.append(el('p', 'warning', v.refreshError || '稿件暂时失效，已保留记录与书签'));
  const details = el('details', 'bookmark-area'); details.open = openDetails.has(key); const summary = el('summary'); summary.innerHTML = icons.bookmark; summary.append(document.createTextNode(`时间书签 · ${v.bookmarks.length}`)); const chev = el('span', 'chevron'); chev.innerHTML = icons.chevron; summary.append(chev); details.append(summary); details.addEventListener('toggle', () => details.open ? openDetails.add(key) : openDetails.delete(key));
  const marks = el('ul', 'bookmark-list');
  for (const b of [...v.bookmarks].sort((a, b) => a.sec - b.sec)) {
    const row = el('li', 'bookmark-row'); const jump = button('', `跳转 ${formatTime(b.sec)} ${b.note}`, () => send('OPEN', { key, mode: 'bookmark', id: b.id }), 'bookmark-jump'); jump.append(el('time', '', formatTime(b.sec)), el('span', '', b.note || '未填写备注')); jump.title = `${b.note || '时间书签'} · ${new Date(b.createdAt).toLocaleString('zh-CN')}`; row.append(jump);
    row.append(button('✎', '修改书签备注', () => noteDialog({ type: 'BOOKMARK_EDIT', key, id: b.id, sec: b.sec, note: b.note })), button('×', '删除书签', () => send('BOOKMARK_DELETE', { key, id: b.id }))); marks.append(row);
  }
  details.append(marks, button('＋ 记录当前播放时间', '记录当前播放时间', async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true }); const tab = tabs[0];
    if (!tab?.id || !tab.url?.startsWith('https://www.bilibili.com/video/')) throw new Error('请先打开对应分P的视频页，再记录当前播放时间');
    let response; try { response = await chrome.tabs.sendMessage(tab.id, { type: 'CURRENT_BOOKMARK', key }); } catch { throw new Error('请刷新视频页后再记录书签'); }
    if (!response?.ok) throw new Error(response?.error || '当前播放页尚未就绪');
    noteDialog({ type: 'BOOKMARK_ADD', key, sec: response.sec, note: '' });
  }, 'add-bookmark')); node.append(details); return node;
}
function pendingCard(key, p) {
  const node = el('article', 'pending'); node.append(el('h3', '', '等待补全视频信息'), el('p', '', p.url), el('p', '', p.error));
  const actions = el('div', 'pending-actions'); actions.append(button('重试获取', '重试获取视频信息', async () => { const r = await send('RETRY', { url: p.url, entire: p.entire }); toast(r.message); }, 'secondary'), button('移除链接', '移除待补全链接', async () => { const r = await send('DELETE_PENDING', { key }); toast('已移除待补全链接', r.undoId, 8000); }, 'secondary')); node.append(actions); return node;
}
function render() {
  const focus = document.activeElement;
  const scroll = document.documentElement.scrollTop;
  const videos = Object.entries(state.videos).sort(([, a], [, b]) => Number(b.pinned) - Number(a.pinned) || b.lastWatchedAt - a.lastWatchedAt || b.addedAt - a.addedAt);
  const pending = Object.entries(state.pending || {});
  $('#count').textContent = videos.length + pending.length;
  const filtered = videos.filter(([, v]) => filter === 'all' || (filter === 'completed' ? isComplete(v, state.settings) : !isComplete(v, state.settings)));
  const entries = [...(filter === 'all' ? pending.map(([key, value]) => ({ key, value, pending: true })) : []), ...filtered.map(([key, value]) => ({ key, value }))];
  const pages = Math.max(1, Math.ceil(entries.length / PAGE_SIZE)); page = Math.min(page, pages);
  const fragment = document.createDocumentFragment();
  for (const [index, entry] of entries.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE).entries()) fragment.append(entry.pending ? pendingCard(entry.key, entry.value) : card(entry.key, entry.value, index));
  if (!entries.length) { const node = el('div', 'empty'); const art = el('div', 'empty-art'); art.innerHTML = icons.bookmark; node.append(art, el('h3', '', videos.length || pending.length ? '这里还没有视频' : '值得再看的，放在这里'), el('p', '', videos.length || pending.length ? '换个筛选，继续你的观看清单。' : '粘贴 B站视频链接，添加第一条关注。'), el('p', '', videos.length || pending.length ? '' : '也可以在视频页点击「重点关注」。')); if (!videos.length && !pending.length) node.append(button('＋ 添加第一个视频', '添加第一个视频', () => $('#video-link').focus(), 'secondary')); fragment.append(node); }
  $('#list').replaceChildren(fragment); $('#list').setAttribute('aria-busy', 'false'); $('#pagination').hidden = pages <= 1; $('#page-number').textContent = `${page} / ${pages}`; $('#prev').disabled = page <= 1; $('#next').disabled = page >= pages;
  document.documentElement.scrollTop = scroll;
  if (focus && document.contains(focus)) focus.focus({ preventScroll: true });
}
function noteDialog(action) { dialogAction = action; $('#note-title').textContent = action.type === 'BOOKMARK_EDIT' ? '修改书签备注' : '记录时间点'; $('#note-time').textContent = formatTime(action.sec); $('#note-input').value = action.note; $('#note-error').hidden = true; $('#note-dialog').showModal(); $('#note-input').focus(); }
for (const id of ['note-close', 'note-cancel']) $(`#${id}`).addEventListener('click', () => $('#note-dialog').close());
$('#note-form').addEventListener('submit', async e => { e.preventDefault(); const b = $('#note-form button[type=submit]'); b.disabled = true; try { const { type, ...payload } = dialogAction; await send(type, { ...payload, note: $('#note-input').value }); $('#note-dialog').close(); toast(type === 'BOOKMARK_ADD' ? '书签已保存，续播位置保持不变' : '备注已更新'); } catch (e) { $('#note-error').textContent = e.message; $('#note-error').hidden = false; } finally { b.disabled = false; } });
$('#add-form').addEventListener('submit', async e => {
  e.preventDefault(); const b = $('#add-form button'); b.disabled = true; b.textContent = '…'; $('#add-error').hidden = true;
  try { const r = await send('ADD', { url: $('#video-link').value, entire: $('#entire').checked }); $('#video-link').value = ''; page = 1; filter = 'all'; setFilter(); render(); toast(r.message, undefined, r.pending ? 6500 : 4200); }
  catch (e) { $('#add-error').textContent = e.message; $('#add-error').hidden = false; } finally { b.disabled = false; b.textContent = '＋'; }
});
function setFilter() { for (const b of document.querySelectorAll('[data-filter]')) { b.classList.toggle('selected', b.dataset.filter === filter); b.setAttribute('aria-pressed', String(b.dataset.filter === filter)); } }
for (const b of document.querySelectorAll('[data-filter]')) b.addEventListener('click', () => { filter = b.dataset.filter; page = 1; setFilter(); render(); });
$('#prev').addEventListener('click', () => { page--; render(); }); $('#next').addEventListener('click', () => { page++; render(); });
$('#settings-toggle').addEventListener('click', () => { $('#settings').hidden = !$('#settings').hidden; $('#settings-toggle').setAttribute('aria-expanded', String(!$('#settings').hidden)); if (!$('#settings').hidden) cleanupUI(); });
for (const [id, key, boolean] of [['new-tab', 'openInNewTab', true], ['default-entire', 'addEntireCollectionDefault', true], ['interval', 'sampleIntervalSec'], ['completion', 'completionPercent'], ['remaining', 'completionRemainingSec'], ['cleanup-days', 'cleanupAfterDays'], ['cleanup-keep', 'cleanupKeepBookmarked', true], ['auto-cleanup', 'autoCleanup', true]]) $(`#${id}`).addEventListener('change', async e => { const b = e.target; b.disabled = true; try { await send('SETTINGS', { settings: { [key]: boolean ? b.checked : Number(b.value) } }); } catch (e) { toast(e.message); settingsUI(); } finally { b.disabled = false; } });
async function chooseTheme(theme) { try { await send('SETTINGS', { settings: { theme } }); } catch (e) { toast(e.message); } }
$('#theme-toggle').addEventListener('click', () => chooseTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
for (const b of document.querySelectorAll('[data-theme-choice]')) b.addEventListener('click', () => chooseTheme(b.dataset.themeChoice));
$('#cleanup-run').addEventListener('click', async () => { const b = $('#cleanup-run'); b.disabled = true; try { const r = await send('CLEANUP'); toast(r.message, r.undoId, 8000); } catch (e) { toast(e.message); } finally { cleanupUI(); } });
$('#cleanup-undo').addEventListener('click', async () => { try { await send('UNDO', { id: $('#cleanup-undo').dataset.id }); toast('已恢复最近一次自动清理的记录'); } catch (e) { toast(e.message); } });
$('#export').addEventListener('click', () => {
  const backup = { schemaVersion: 1, exportedAt: Date.now(), videos: state.videos, pending: state.pending, settings: state.settings };
  const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' })); const a = el('a'); a.href = url; a.download = `重点关注-备份-${new Date().toLocaleDateString('sv-SE')}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000); toast('已导出本机 JSON 备份');
});
$('#import').addEventListener('click', () => $('#import-file').click());
$('#import-file').addEventListener('change', async e => {
  const file = e.target.files[0]; if (!file) return; $('#import').disabled = true;
  try { if (file.size > 8 * 1024 * 1024) throw new Error('备份超过 8MB，请检查文件'); const data = JSON.parse(await file.text()); const r = await send('IMPORT', { data }); toast(r.message); }
  catch (e) { toast(e instanceof SyntaxError ? '这不是有效的 JSON 备份文件' : e.message, undefined, 6500); } finally { e.target.value = ''; $('#import').disabled = false; }
});
function onStorage(changes, area) {
  if (area !== 'local' || !changes[STATE_KEY]?.newValue) return;
  const next = changes[STATE_KEY].newValue;
  if (next.schemaVersion !== 1) return;
  const previous = state;
  const progressFields = new Set(['positionSec', 'maxPositionSec', 'lastWatchedAt', 'completed']);
  const structural = s => JSON.stringify({ settings: s.settings, pending: s.pending, videos: Object.entries(s.videos).map(([key, v]) => [key, Object.fromEntries(Object.entries(v).filter(([k]) => !progressFields.has(k)))]) });
  const onlyProgress = structural(previous) === structural(next) && Object.keys(next.videos).every(key => isComplete(previous.videos[key], previous.settings) === isComplete(next.videos[key], next.settings));
  if (onlyProgress) {
    state = { ...emptyState(), ...next, settings: normalizeSettings(next.settings) };
    for (const node of $('#list').querySelectorAll('.card')) {
      const v = state.videos[node.dataset.key]; if (!v) continue;
      const target = resumeTarget(v, state.settings);
      node.querySelector('.progress-info strong').textContent = isComplete(v, state.settings) ? '已看完' : v.lastWatchedAt ? '上次看到' : '等待开始';
      node.querySelector('.progress-info span').textContent = `${formatTime(v.positionSec)} / ${formatTime(v.duration)}`;
      node.querySelector('.progress-bar').style.setProperty('--progress', v.duration ? Math.min(1, v.positionSec / v.duration) : 0);
      const resume = node.querySelector('.primary'); resume.title = target.label; resume.setAttribute('aria-label', target.label); resume.querySelector('.play-symbol').lastChild.textContent = target.label;
      node.querySelector('.last-watch>span').textContent = target.lastPage ? '已是最后一P' : relative(v.lastWatchedAt);
    }
    if (!$('#settings').hidden) cleanupUI();
    return;
  }
  // Preserve focus for structural updates such as bookmark edits.
  const active = document.activeElement;
  const focusLabel = $('#list').contains(active) ? active.getAttribute('aria-label') : null;
  state = { ...emptyState(), ...next, settings: normalizeSettings(next.settings) }; render(); settingsUI();
  if (focusLabel) [...$('#list').querySelectorAll('[aria-label]')].find(b => b.getAttribute('aria-label') === focusLabel)?.focus({ preventScroll: true });
}
chrome.storage.onChanged.addListener(onStorage);
window.addEventListener('pagehide', () => { chrome.storage.onChanged.removeListener(onStorage); systemTheme.removeEventListener('change', applyTheme); clearTimeout(toastTimer); }, { once: true });
try {
  // The popup's only initial storage read. No network request gates rendering.
  const result = await chrome.storage.local.get(STATE_KEY);
  if (result[STATE_KEY]?.schemaVersion && result[STATE_KEY].schemaVersion !== 1) throw new Error('本机数据版本暂不支持');
  state = { ...emptyState(), ...result[STATE_KEY], settings: normalizeSettings(result[STATE_KEY]?.settings) };
  settingsUI(); $('#entire').checked = state.settings.addEntireCollectionDefault; render();
  const recent = Object.entries(state.trash).filter(([, t]) => t.expiresAt > Date.now()).sort(([, a], [, b]) => b.expiresAt - a.expiresAt)[0];
  if (recent) toast(recent[1].kind === 'batch' ? `已${recent[1].automatic ? '自动' : ''}清理 ${recent[1].count} 条旧记录` : '刚刚移除了一个条目', recent[0], Math.min(8000, recent[1].expiresAt - Date.now()));
} catch (e) { $('#list').setAttribute('aria-busy', 'false'); const error = el('div', 'empty'); error.append(el('h3', '', '暂时无法读取本机清单'), el('p', '', e.message), button('重新读取', '重新读取本机清单', () => location.reload(), 'secondary')); $('#list').replaceChildren(error); }
